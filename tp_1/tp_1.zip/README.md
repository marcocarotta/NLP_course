## Installation and Usage

To install the required packages, run:
```bash
pip install -r requirements.txt
```

To execute the script, run:
```bash
python script.py
```

The custom dataset should be inserted in the folder tp_1